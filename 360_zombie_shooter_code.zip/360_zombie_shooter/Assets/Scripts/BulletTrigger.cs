﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletTrigger : MonoBehaviour
{


	void OnTriggerEnter (Collider col)
	{
		//This will help to destroy AI enemies when hit by players bullet.

//		if (col.gameObject.name.Contains (this.gameObject.name) && col.gameObject.tag != "Enemy") {
//			Destroy (col.gameObject);
//			StartCoroutine (DestroyEnemy ());
//		}

		if (col.gameObject.name.Contains ("Bullet")) {

			Destroy (col.gameObject);
			StartCoroutine (DestroyEnemy ());
		}

		if (col.gameObject.name.Contains ("CubeZombie")) {
			PlayerHealth.HealthCount = PlayerHealth.HealthCount + 0.2f;
			AIMove_Zombie ai = this.gameObject.GetComponent<AIMove_Zombie> ();
			ai.m_bStopCube = true;
		}


	}

	// Enemy explosion and destroy
	IEnumerator DestroyEnemy ()
	{
		this.gameObject.GetComponent<MeshRenderer> ().enabled = false;
		this.transform.GetChild (0).gameObject.SetActive (true);
		yield return new WaitForSeconds (0.5f);
		Destroy (this.gameObject);
	}
}
