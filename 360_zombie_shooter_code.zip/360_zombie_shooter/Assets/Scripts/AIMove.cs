using UnityEngine;


public class AIMove : MonoBehaviour
{
	
	public  GameObject PathListGO;
	public Transform[] PathListTR;
	public int StartPoint;
	public int EndWayPoint = 0;
	public int CurrentWaypoint = 0;
	public bool m_bStopCube = false;
	Rigidbody rig;
	public float navigationSpeed = 10;
	Transform playerTransform;

	internal void StartAi ()
	{
		this.enabled = true;
		m_bStopCube = false;
		Start ();
	}

	void Start ()
	{
		
		rig = this.GetComponent<Rigidbody> ();
		GetComponent<Rigidbody> ().centerOfMass = new Vector3 (0, 0, 1.0F);
		m_bStopCube = false;

		if (PathListGO == null) {
			m_bStopCube = true;

			rig.isKinematic = true;
			this.enabled = false;
		}
		GetALLWaypoints ();
		playerTransform = GameObject.Find ("Player").GetComponent<Transform> ();

	}

	
	void FixedUpdate ()
	{
		if (!m_bStopCube)
			Navigation ();

		float distance = Vector3.Distance (transform.position, playerTransform.position);

		if (distance < 10) {
			//Stop moving
			//Write code here
		}

		Vector3 fwd = transform.TransformDirection (Vector3.forward);
		RaycastHit hit;

		if (Physics.Raycast (transform.position, fwd, out hit, 2.0f)) {
			if (hit.collider.name.Contains ("Signal") && !hit.collider.gameObject.GetComponent<TrafficLight> ().isGreen) {
				m_bStopCube = true;
			} else {

				Debug.Log ("Its making false");
				m_bStopCube = false;
			}
		}
	
	}


	void SelectNewPath ()
	{
		if (PathListGO == null)
			return;

		Pathlines[] outPath = PathListGO.GetComponent<Pathlines> ().OutwardPaths;

		if (outPath.Length > 0) {
			PathListGO = outPath [0].gameObject;
			GetALLWaypoints ();

			StartPoint = 0;
			CurrentWaypoint = 0;
			EndWayPoint = PathListTR.Length;
		} else
			m_bStopCube = true;
		
	}
    

	/*this part is use to get all the waypoints and make object move*/

	public void GetALLWaypoints ()
	{
		if (PathListGO == null)
			return;
        		
		Pathlines line;
		
		
		line = PathListGO.GetComponent< Pathlines > ();
		
		PathListTR = new Transform[ line.AItargets.Length ];
		
		for (int x = 0; x < PathListTR.Length; x++) {//loop for no of waypoints
			PathListTR [x] = line.AItargets [x];						
		}		
		
	}

	public bool debug = false;

	float rotY;

	void Navigation ()
	{
		//This will take the direction od the waypoint to be navigated
		if (CurrentWaypoint == 0)
			CurrentWaypoint++;
		if (CurrentWaypoint >= PathListTR.Length) {
			SelectNewPath ();
			return;

		}
		try {
			Vector3 DestinationWaypoint = transform.InverseTransformPoint (new Vector3 (
				                              PathListTR [CurrentWaypoint].position.x,
				                              transform.position.y,
				                              PathListTR [CurrentWaypoint].position.z)); 
		
		
			float destinationMagnitude = DestinationWaypoint.magnitude;
			
			if (destinationMagnitude < 0.8F)
				CurrentWaypoint++;

			Vector3 destination = new Vector3 (PathListTR [CurrentWaypoint].position.x, transform.position.y,
				                      PathListTR [CurrentWaypoint].position.z);

			transform.position = Vector3.Lerp (transform.position, destination, Time.deltaTime * 0.01F * navigationSpeed);

			transform.LookAt (PathListTR [CurrentWaypoint].position);

		} catch {
		}
        
	}
    
}
