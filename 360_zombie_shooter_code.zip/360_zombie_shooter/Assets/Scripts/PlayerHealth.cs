﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerHealth : MonoBehaviour
{
	public static float HealthCount;
	public Image healthBar;
	// Use this for initialization
	void Start ()
	{
		healthBar.GetComponent<Image> ().fillAmount = 1f;
		HealthCount = 10;
	}
	
	// Update is called once per frame
	void Update ()
	{
		healthBar.GetComponent<Image> ().fillAmount = HealthCount / 10f;

		if (HealthCount < 1) {
			SceneManager.LoadScene (2);
		}
	}
}
