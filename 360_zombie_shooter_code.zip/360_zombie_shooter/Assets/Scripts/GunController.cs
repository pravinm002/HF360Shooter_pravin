using UnityEngine;
using System.Collections;

public class GunController : MonoBehaviour
{

	public float fireRate = 0.25f;
	public float weaponRange = 50f;
	public float hitForce = 100f;
	public Transform gunEnd;
	private Camera fpsCam;

	private AudioSource gunAudio;
	private LineRenderer laserLine;
	private float nextFire;
	public float BulletForce;
	public ParticleSystem GunFlash;
	// Use this for initialization
	public GameObject m_o_bullet;
	GameObject bulletHolder;

	void Start ()
	{
		laserLine = GetComponent<LineRenderer> ();
		gunAudio = GetComponent<AudioSource> ();
		fpsCam = GetComponentInParent<Camera> ();
	}
	
	// Update is called once per frame
	void Update ()
	{
		// To fire blue bullet

		if (Input.GetKeyDown (KeyCode.Space) && Time.time > nextFire) {

			FireBullet ();
			RaycastLaser ();

		} 
	}

	// To draw laser while shooting bullet
	void RaycastLaser ()
	{
		nextFire = Time.time + fireRate;
		StartCoroutine (ShotEffect ());
		Vector3 rayOrigin = fpsCam.ViewportToWorldPoint (new Vector3 (0.5f, 0.5f, 0.0f));
		RaycastHit hit;
		laserLine.SetPosition (0, gunEnd.position);

		if (Physics.Raycast (rayOrigin, fpsCam.transform.forward, out hit, weaponRange)) {
			laserLine.SetPosition (1, hit.point);


		} else {
			laserLine.SetPosition (1, rayOrigin + (fpsCam.transform.forward * weaponRange));
		}
	}


	// To show the laser and gun flash particle effect
	private IEnumerator ShotEffect ()
	{
		
		laserLine.enabled = true;
		laserLine.SetColors (Color.red, Color.red);
		GunFlash.Play ();
		yield return new WaitForSeconds (0.2f);
		gunAudio.Play ();
		laserLine.enabled = false;
	}


	// to fire bullet towards player

	void FireBullet ()
	{
		
		bulletHolder = Instantiate (m_o_bullet, gunEnd.position, gunEnd.transform.rotation) as GameObject;
		bulletHolder.transform.Rotate (Vector3.left * 0);
		Rigidbody Bullet_RigidBody;
		Bullet_RigidBody = bulletHolder.GetComponent<Rigidbody> ();
		Bullet_RigidBody.AddForce (transform.forward * BulletForce, ForceMode.Impulse);
		bulletHolder.gameObject.transform.parent = gunEnd.transform;
		if (bulletHolder.gameObject != null)
			Destroy (bulletHolder, 2.0f);
	}
}
