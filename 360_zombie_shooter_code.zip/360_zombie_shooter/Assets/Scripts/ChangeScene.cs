﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour
{

	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{

		// To quit the game
		if (Input.GetKeyDown (KeyCode.Escape)) {
			Application.Quit ();
		}	
	}

	// Navigation between scenes
	public void GotoGame ()
	{
		SceneManager.LoadScene (1);
	}

	public void LoadIntro ()
	{
		SceneManager.LoadScene (0);
	}
}
