﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombiesSpawner : MonoBehaviour
{

	public float spawnTimes = 2.0f;
	public GameObject[] Zombies;
	public Transform parentZombie;
	public GameObject path;

	// Use this for initialization
	void Start ()
	{
		InvokeRepeating ("Spawnzombies", spawnTimes, spawnTimes);
	}


	void Spawnzombies ()
	{
		PlayerHealth.HealthCount = PlayerHealth.HealthCount - 0.2f;
		GameObject zombie = Instantiate (Zombies [0], this.transform.position, this.transform.rotation) as GameObject;
		zombie.transform.eulerAngles = new Vector3 (0, 0, 180f);
		zombie.transform.parent = parentZombie.transform;
		AIMove_Zombie ai = zombie.GetComponent<AIMove_Zombie> ();
		ai.PathListGO = path;
		ai.StartAi ();
	}

}
