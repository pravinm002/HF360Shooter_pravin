﻿using System.Collections;
using UnityEngine;

public class TrafficLight : MonoBehaviour
{

	float duration = 0f;
	public bool isGreen = false;
	// Use this for initialization
	void Start ()
	{
		this.GetComponent<MeshRenderer> ().material.color = Color.red;
		InvokeRepeating ("ChangeColor", 0f, 5f);
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}

	void ChangeColor ()
	{
		StartCoroutine ("ColorChanger");
	}


	IEnumerator ColorChanger ()
	{
		duration = Random.Range (2.0f, 8.0f);
		//	yield return new WaitForSeconds (duration);
		this.GetComponent<MeshRenderer> ().material.color = Color.red;
		isGreen = false;
		yield return new WaitForSeconds (duration);
		this.GetComponent<MeshRenderer> ().material.color = Color.green;
		isGreen = true;


	


	}
}
