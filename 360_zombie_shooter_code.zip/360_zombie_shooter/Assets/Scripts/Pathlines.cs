using UnityEngine;


public class Pathlines : MonoBehaviour 
{	
	public Transform [] AItargets  ;
	public Color Linecolor ;
	public bool drawGizmo  = true; 
	Renderer [] render;	
	public Pathlines[] OutwardPaths;	//For looping purpose
    

	void Start() {
	
	
		render = this.gameObject.GetComponentsInChildren<Renderer>();
		
		foreach(Renderer r in render){
		
			if( r != null)
				r.enabled = false;
		}
			
		drawGizmo = false;
		this.enabled = false;
		
		
	}

	void OnDrawGizmos () {
	
		if( !drawGizmo )
			return;
			
		//var waypoints = gameObject.GetComponentsInChildren( Transform );
		Gizmos.color = Linecolor;
	
		int i =0 ;		
				while(i<AItargets.Length-1){
               
                Gizmos.DrawLine(AItargets[i].position, AItargets[i + 1].position);
                Gizmos.DrawWireSphere(AItargets[i + 1].position, 0.5f);
                i++;			
				}   	
	 } 
}



