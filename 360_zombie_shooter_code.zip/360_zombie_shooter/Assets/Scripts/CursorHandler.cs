﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;

public class CursorHandler : MonoBehaviour
{

	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{

		// To quit game
		if (Input.GetKeyDown (KeyCode.Escape)) {
			Application.Quit ();
		}	
	}


	// Cursor visibility code
	void OnLevelWasLoaded (int level)
	{
		if (FindObjectOfType<FirstPersonController> () != null) {
			Cursor.visible = false;
		} else {
			Cursor.visible = true;
		}
	}
}
